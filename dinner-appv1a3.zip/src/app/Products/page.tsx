const ProductPage = () => {
  return <h1 className="text-red-500">products page</h1>;
};

export default ProductPage;
